import uuid
import requests
import logging
from flask import Flask, render_template, request, jsonify
from database import save_summary, get_summary

# Initialize Flask app
app = Flask(__name__, template_folder="templates")  # Ensure "templates" directory exists

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Define the correct n8n webhook URL (Production mode)
N8N_URL = "http://localhost:5678/webhook/ytube"  # Use /webhook/ytube for active workflows

@app.route("/")
def index():
    """ Serve the main HTML page """
    return render_template("index.html")

@app.route("/generate-summary", methods=["POST"])
def generate_summary():
    try:
        data = request.get_json()
        video_url = data.get("video_url")

        if not video_url:
            return jsonify({"error": "No video URL provided"}), 400

        # Check if the summary already exists in the database
        existing_summary = get_summary(video_url)
        if existing_summary:
            return jsonify({"summary": existing_summary["summary"]})

        # Call n8n webhook to trigger workflow automatically
        response = requests.post(N8N_URL, json={"video_url": video_url}, timeout=15)

        if response.status_code != 200:
            logging.error(f"n8n webhook error: {response.status_code} - {response.text}")
            return jsonify({"error": "Failed to trigger n8n workflow"}), 500

        # Extract summary from response
        summary_data = response.json()
        summary = summary_data.get("summary")

        if not summary:
            logging.error("n8n response missing 'summary' key")
            return jsonify({"error": "Summary generation failed"}), 500

        # Generate a unique user ID
        user_id = str(uuid.uuid4())

        # Save summary in Nhost database
        saved_summary = save_summary(video_url, summary, user_id)
        if saved_summary:
            return jsonify({"summary": saved_summary["summary"]})
        else:
            return jsonify({"error": "Failed to save summary to Nhost database"}), 500

    except requests.exceptions.RequestException as e:
        logging.error(f"Error calling n8n webhook: {e}")
        return jsonify({"error": "Could not connect to n8n workflow"}), 500
    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)  # Run on localhost:5000
