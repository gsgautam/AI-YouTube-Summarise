import os
import requests
from urllib.parse import urlparse, parse_qs

# Use environment variable for ADMIN_SECRET
ADMIN_SECRET = os.getenv('h+!qGR;oBs_t+pogZ-zThS#$-Z*bj3R1')
GRAPHQL_URL = "https://kkhkfefqnpmnkdtxmdgy.hasura.ap-south-1.nhost.run/v1/graphql"

def normalize_youtube_url(video_url):
    """Standardize YouTube URLs to canonical format"""
    # Handle shortened youtu.be URLs
    if 'youtu.be' in video_url:
        video_id = urlparse(video_url).path.lstrip('/')
        return f"https://www.youtube.com/watch?v={video_id.split('?')[0]}"
    
    # Standardize YouTube watch URLs
    if 'watch?v=' in video_url:
        video_id = parse_qs(urlparse(video_url).query).get('v', [''])[0]
        return f"https://www.youtube.com/watch?v={video_id}"
    
    return video_url

def get_summary(video_url):
    """Fetch summary with normalized URL"""
    video_url = normalize_youtube_url(video_url)
    
    query = """
    query get_summary($video_url: String!) {
        auto_summary_auto_summary(where: {video_url: {_eq: $video_url}}) {
            summary
            video_url
            id
            user_id
        }
    }
    """
    variables = {"video_url": video_url}
    headers = {"x-hasura-admin-secret": ADMIN_SECRET}

    try:
        response = requests.post(GRAPHQL_URL, json={'query': query, 'variables': variables}, headers=headers)
        response.raise_for_status()
        data = response.json()
        
        if data.get('errors'):
            print(f"GraphQL Error: {data['errors']}")
            return None
            
        return data['data']['auto_summary_auto_summary'][0] if data['data']['auto_summary_auto_summary'] else None
        
    except Exception as e:
        print(f"Fetch Error: {str(e)}")
        return None

def save_summary(video_url, summary, user_id):
    """Save summary with normalized URL and immediate availability"""
    video_url = normalize_youtube_url(video_url)
    
    # Check existing summary with normalized URL
    if (existing := get_summary(video_url)):
        print(f"Summary exists: {existing['summary']}")
        return existing

    mutation = """
    mutation insert_auto_summary($video_url: String!, $summary: String!, $user_id: uuid!) {
        insert_auto_summary_auto_summary(objects: {video_url: $video_url, summary: $summary, user_id: $user_id}) {
            affected_rows
            returning {
                summary
                video_url
                id
                user_id
            }
        }
    }
    """
    variables = {"video_url": video_url, "summary": summary, "user_id": user_id}
    headers = {"x-hasura-admin-secret": ADMIN_SECRET}

    try:
        response = requests.post(GRAPHQL_URL, json={"query": mutation, "variables": variables}, headers=headers)
        response.raise_for_status()
        data = response.json()
        
        if data.get('errors'):
            print(f"Mutation Error: {data['errors']}")
            return None
            
        result = data['data']['insert_auto_summary_auto_summary']['returning'][0]
        print(f"Saved summary: {result}")
        return result
        
    except Exception as e:
        print(f"Save Error: {str(e)}")
        return None

# Usage Example
if __name__ == "__main__":
    test_url = "https://youtu.be/X8BYu3dMKf0"  # Shortened URL
    summary = "This is a comprehensive video summary..."
    user_id = "d61c90a7-20e0-42b0-a7a9-f2cbe6f2b758"

    # Test normalization and saving
    saved = save_summary(test_url, summary, user_id)
    print(f"Saved: {saved}")

    # Test fetching with different URL format
    fetched = get_summary("https://www.youtube.com/watch?v=X8BYu3dMKf0")
    print(f"Fetched: {fetched['summary'] if fetched else 'No summary'}")